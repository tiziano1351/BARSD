How to run the Small CRM  Project
1. Download the  zip file

2. Extract the file and copy crm folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name crm

6. Import crm.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/crm (frontend)

8.Run the script http://localhost/crm/admin 

Credential for admin panel :

Username: admin
Password: admin

Credential for user panel :

Username: recursivoweb@mail.com
Password: Demo@123